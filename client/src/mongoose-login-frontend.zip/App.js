import React, { useState } from "react";
import Registration from "./components/Registration";
import Login from "./components/Login";
import Update from "./components/Update";
import "./App.css";

export default function App() {
  const [userInfo, setUserInfo] = useState({});
  return (
    <article>
      <h1>
        <span className="icon">🐸</span> Frog Project Manager
      </h1>
      <Registration />
      <Login userInfo={userInfo} setUserInfo={setUserInfo} />
      <Update userInfo={userInfo} />
    </article>
  );
}
